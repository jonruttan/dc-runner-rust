# spec_runner_cli

Rust CLI implementation behind the repository-level `runner_adapter.sh`.

This crate is intentionally focused on deterministic runner behavior for Data Contracts.
For full project context and adapter usage, see the repository root `README.md`.
